﻿namespace EmployeeWebApi.Models
{
    public class Department
    {
        public int DepartmentId { get; set; }
        public String DepartmentName { get; set; }
    }
}
