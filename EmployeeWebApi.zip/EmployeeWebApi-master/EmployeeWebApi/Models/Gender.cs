﻿namespace EmployeeWebApi.Models
{
    public enum Gender

    {
        Male,
        Female
    }

}
